﻿using Amba.SpreadsheetLight;
using ExcelDataReader;
using Microsoft.Office.Interop.Excel;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Console.WriteLine("chowhsienwu..");
        }

        private class InfoNode
        {
            public string Name = "";
            public string Time = "";
            public DateTime DateTime;
        }
        List<InfoNode> _RawInfoList = new List<InfoNode>();

        private void InitCal()
        {
            _RawInfoList.Clear();
            LastInfo.Clear();
            savefilename = "";
            setlableText("----------");
        }
        private string rawfile = "";
        private void button1_Click(object sender, EventArgs e)
        {
            InitCal(); 

            OpenFileDialog fdlg = new OpenFileDialog();
            fdlg.Title = "Excel File Dialog";
            fdlg.Filter = "All files (*.*)|*.*|All files (*.*)|*.*";
            fdlg.FilterIndex = 2;
            fdlg.RestoreDirectory = true;
            if (fdlg.ShowDialog() == DialogResult.OK)
            {
                rawfile = fdlg.FileName;
                setlableText("正在打开文件 " + rawfile);
                BackgroundWorker worker = new BackgroundWorker();
                worker.DoWork += Worker_DoWork;
                worker.RunWorkerCompleted += Worker_RunWorkerCompleted;
                worker.RunWorkerAsync();

                button1.Enabled = false;
            }
        }

        private void Worker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            button1.Enabled = true;
        }

        private delegate void myDelegate(string bl);
        private void setlableText(string text)
        {
            if (this.label1.InvokeRequired)
            {
                myDelegate md = new myDelegate(this.setlableText);
                this.Invoke(md, new object[] { text });
            }
            else
                this.label1.Text = text;
        }

        private void DoReadFile(object sender, DoWorkEventArgs e)
        {
            setlableText("DoReadFile...x..........1 ");
            FileStream teststream = File.OpenRead(rawfile);
            using (var reader = ExcelReaderFactory.CreateReader(teststream))
            {
                int rowCount = reader.RowCount; //1872
                setlableText("文件正在加载 0%");
                do
                {
                    while (reader.Read())
                    {
                        if (reader.Depth != 0)
                        {
                            InfoNode node = new InfoNode();
                            node.Name = reader.GetString(1);
                            node.Time = reader.GetString(3);
                            node.DateTime = DateTime.Parse(node.Time);
                            _RawInfoList.Add(node);

                            if (reader.Depth % 100 == 0)
                            {
                                setlableText("文件正在加载 第" + reader.Depth + "...行 " + (reader.Depth * 1.0 / rowCount) * 100 + " %");
                            }
                        }
                    }
                } while (reader.NextResult());
            }
            teststream.Close();
            setlableText("文件加载 完成");

            Console.Out.WriteLine("end load file " + DateTime.Now);
            ParseData();
            Console.Out.WriteLine("end parse " + DateTime.Now);
            setlableText("数据解析 完成");
            setlableText("正在保存到表格文件 0%");
            // SaveDatatoXls();
            SaveDatatoXls2();
            Console.Out.WriteLine("end save " + DateTime.Now);
            setlableText("数据保存 完成!!! " + Path.GetFullPath(savefilename));
        }





        private void Worker_DoWork(object sender, DoWorkEventArgs e)
        {
            DoReadFile(sender, e);
            return;

            setlableText("Worker_DoWork...x..........1 ");
            Microsoft.Office.Interop.Excel.Application xlApp = null;
            try
            {
                xlApp = new Microsoft.Office.Interop.Excel.Application();
            }
            catch(Exception e1)
            {
                setlableText("Worker_DoWork........ new Microsoft.Office.Interop.Excel.Application()....error " + e1.ToString());
                Console.Out.WriteLine("Worker_DoWork........ new Microsoft.Office.Interop.Excel.Application()....error " + e1.ToString());
            }
           
            setlableText("Worker_DoWork............2 " + xlApp);
            Microsoft.Office.Interop.Excel.Workbook xlWorkbook = xlApp.Workbooks.Open(rawfile);
            setlableText("Worker_DoWork...........3 " + xlWorkbook);
            if (xlWorkbook == null)
            {
                Console.Out.WriteLine("open file error");
                setlableText("文件打开失败");
                return;
            }
            setlableText("文件打开成功");

            Microsoft.Office.Interop.Excel._Worksheet xlWorksheet = xlWorkbook.Sheets[1];
            Microsoft.Office.Interop.Excel.Range xlRange = xlWorksheet.UsedRange;

            int rowCount = xlRange.Rows.Count; //1872
            int colCount = xlRange.Columns.Count; //9

            setlableText("文件正在加载 0%");
            Console.Out.WriteLine("start load file " + DateTime.Now);
            try
            {
                for (int i = 2; i <= rowCount; i++) //start from line 2 ;第1行为表头信息.
                {
                    InfoNode node = new InfoNode();
                    node.Name = xlRange.Cells[i, 2].Value2.ToString();
                    node.Time = xlRange.Cells[i, 4].Value2.ToString();
                    node.DateTime = DateTime.Parse(node.Time);
                    _RawInfoList.Add(node);

                    if (i % 100  == 0)
                    {
                        setlableText("文件正在加载 第" + i + "...行 " + (i *1.0 / rowCount) * 100 + " %" );
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show("错误" + ee.ToString());
            }
            setlableText("文件加载 完成");

            Console.Out.WriteLine("end load file " + DateTime.Now);
            ParseData();
            Console.Out.WriteLine("end parse " + DateTime.Now);
            setlableText("数据解析 完成");
            setlableText("正在保存到表格文件 0%");
            SaveDatatoXls();
            Console.Out.WriteLine("end save " + DateTime.Now);
            setlableText("数据保存 完成!!! " + Path.GetFullPath(savefilename));

            //cleanup  
            GC.Collect();
            GC.WaitForPendingFinalizers();

            //release com objects to fully kill excel process from running in the background  
            Marshal.ReleaseComObject(xlRange);
            Marshal.ReleaseComObject(xlWorksheet);

            //close and release  
            xlWorkbook.Close();
            Marshal.ReleaseComObject(xlWorkbook);

            //quit and release  
            xlApp.Quit();
            Marshal.ReleaseComObject(xlApp);
        }


        private void SaveDatatoXls2()
        {
            Dictionary<DateTime, string> monthdata = LastInfo.Values.ElementAt(0);
            if (monthdata == null)
            {
                return;
            }

            SLDocument sl = new SLDocument();
            //sl.SetCellValue("A1", true);
            sl.SetCellValue(1, 1, "姓名");

            for (int i = 0; i < monthdata.Count; i++)
            {
                sl.SetCellValue(1, 2 + i, monthdata.Keys.ElementAt(i).Month + "月" + monthdata.Keys.ElementAt(i).Day);
                sl.SetWorksheetDefaultColumnWidth(5);

                //if (monthdata.Keys.ElementAt(i).DayOfWeek.Equals(DayOfWeek.Sunday) || monthdata.Keys.ElementAt(i).DayOfWeek.Equals(DayOfWeek.Saturday))
                //{ //周末显示黄色
                //    for (int j = 0; j < LastInfo.Keys.Count + 1; j++)
                //    {
                //        xlWorkSheet.Cells[1 + j, 2 + i].Interior.Color = XlRgbColor.rgbYellow;
                //        sl.setco
                //    }
                //}

              //  SLStyle 
              //  sl.SetColumnStyle(1, )
                 setlableText("正在保存到表格文件 ..");
            }
            // xlWorkSheet.Columns[1].ColumnWidth = 8;
            // xlWorkSheet.Cells.Borders.Color = Color.Black;

            int startline = 2;
            for (int i = 0; i < LastInfo.Keys.Count; i++)
            {
                sl.SetCellValue(startline + i, 1, LastInfo.Keys.ElementAt(i));//名字
                var _EveryDayInfoDir = LastInfo.Values.ElementAt(i);
                for (int j = 0; j < _EveryDayInfoDir.Count; j++)
                {
                    sl.SetCellValue(startline + i, 2 + j,_EveryDayInfoDir.Values.ElementAt(j));
                    //颜色
                    if (_EveryDayInfoDir.Values.ElementAt(j) != null && (_EveryDayInfoDir.Values.ElementAt(j).Contains("迟到") || _EveryDayInfoDir.Values.ElementAt(j).Contains("缺卡")))
                    {
                       // xlWorkSheet.Cells[startline + i, 2 + j].Characters[0, 10].Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Red);
                    }
                    if (_EveryDayInfoDir.Values.ElementAt(j) != null && (_EveryDayInfoDir.Values.ElementAt(j).Contains("h") || _EveryDayInfoDir.Values.ElementAt(j).Contains("m")))
                    {
                     //   xlWorkSheet.Cells[startline + i, 2 + j].Characters[0, 10].Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Green);
                    }
                }

                setlableText("正在保存到表格文件 " + (i * 1.0 / LastInfo.Keys.Count) * 100 + "%");
            }

            savefilename = Path.GetDirectoryName(rawfile);
            savefilename += "\\" + monthdata.Keys.ElementAt(0).Month + "." + monthdata.Keys.ElementAt(0).Day + "-" +
                monthdata.Keys.ElementAt(monthdata.Count - 1).Month + "." + monthdata.Keys.ElementAt(monthdata.Count - 1).Day + "_" +
                "可爱tiki-lau " + DateTime.Now.Ticks + ".xlsx";

            sl.SaveAs(savefilename);
        }
        private void SaveDatatoXls()
        {
            Dictionary<DateTime, string> monthdata = LastInfo.Values.ElementAt(0);
            if (monthdata == null)
            {
                return;
            }
            Microsoft.Office.Interop.Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();

            Microsoft.Office.Interop.Excel.Workbook xlWorkBook;
            Microsoft.Office.Interop.Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;

            xlWorkBook = xlApp.Workbooks.Add(misValue);
            xlWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

            // 
            xlWorkSheet.Cells[1, 1] = "姓名";
            for (int i = 0; i < monthdata.Count; i++)
            {
                xlWorkSheet.Cells[1, 2 + i] = monthdata.Keys.ElementAt(i).Month + "月" + monthdata.Keys.ElementAt(i).Day;
                xlWorkSheet.Columns[i + 1].ColumnWidth = 5;

                if (monthdata.Keys.ElementAt(i).DayOfWeek.Equals(DayOfWeek.Sunday) || monthdata.Keys.ElementAt(i).DayOfWeek.Equals(DayOfWeek.Saturday))
                { //周末显示黄色
                    for (int j = 0; j < LastInfo.Keys.Count + 1; j++)
                    {
                        xlWorkSheet.Cells[1 + j, 2 + i].Interior.Color = XlRgbColor.rgbYellow;
                    }
                }
               // setlableText("正在保存到表格文件 ..");
            }
            xlWorkSheet.Columns[1].ColumnWidth = 8;
            xlWorkSheet.Cells.Borders.Color = Color.Black;

            int startline = 2;
            for (int i = 0; i < LastInfo.Keys.Count; i++)
            {
                xlWorkSheet.Cells[startline + i, 1] = LastInfo.Keys.ElementAt(i);//名字
                var _EveryDayInfoDir = LastInfo.Values.ElementAt(i);
                for (int j = 0; j < _EveryDayInfoDir.Count; j++)
                {
                    xlWorkSheet.Cells[startline + i, 2 + j] = _EveryDayInfoDir.Values.ElementAt(j);
                    if (_EveryDayInfoDir.Values.ElementAt(j) != null && (_EveryDayInfoDir.Values.ElementAt(j).Contains("迟到") || _EveryDayInfoDir.Values.ElementAt(j).Contains("缺卡")))
                    {
                        xlWorkSheet.Cells[startline + i, 2 + j].Characters[0, 10].Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Red);
                    }
                    if (_EveryDayInfoDir.Values.ElementAt(j) != null && (_EveryDayInfoDir.Values.ElementAt(j).Contains("h") || _EveryDayInfoDir.Values.ElementAt(j).Contains("m")))
                    {
                        xlWorkSheet.Cells[startline + i, 2 + j].Characters[0, 10].Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Green);
                    }
                }

                setlableText("正在保存到表格文件 " + (i * 1.0 / LastInfo.Keys.Count) * 100 + "%");
            }

            savefilename = Path.GetDirectoryName(rawfile);
            savefilename += "\\" + monthdata.Keys.ElementAt(0).Month + "." + monthdata.Keys.ElementAt(0).Day + "-" +
                monthdata.Keys.ElementAt(monthdata.Count - 1).Month + "." + monthdata.Keys.ElementAt(monthdata.Count - 1).Day + "_" +
                "可爱tiki-lau " + DateTime.Now.Ticks + ".xls";

            xlWorkBook.SaveAs(savefilename, Microsoft.Office.Interop.Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, 
                Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
            xlWorkBook.Close(true, misValue, misValue);

            Marshal.ReleaseComObject(xlWorkSheet);
            Marshal.ReleaseComObject(xlWorkBook);
            xlApp.Quit();
            Marshal.ReleaseComObject(xlApp);
        }

        string savefilename = "";
        Dictionary<string, Dictionary<DateTime, string>> LastInfo = new Dictionary<string, Dictionary<DateTime, string>>(); //key-名字  value--EeveayDataInfo
        private void ParseData()
        {
            HashSet<string> nameset = new HashSet<string>();
            nameset.Clear();

            DateTime earlyDate = new DateTime(); //最早时间 
            DateTime LateDate = new DateTime();  //最晚时间.
            earlyDate = _RawInfoList[0].DateTime;
            LateDate = _RawInfoList[0].DateTime;

            List<int> namestartpos = new List<int>();
            List<int> nameendpos = new List<int>();
            for (int i = 0; i < _RawInfoList.Count; i++)
            {
                InfoNode node = _RawInfoList[i];
                if (!nameset.Contains(node.Name))
                {
                    namestartpos.Add(i);
                    nameendpos.Add(i);
                }
                else
                {
                    nameendpos[namestartpos.Count - 1] = i;
                }
                nameset.Add(node.Name);
              
                if (DateTime.Compare(earlyDate, node.DateTime) > 0)
                {
                    earlyDate = node.DateTime;   
                }
                if (DateTime.Compare(LateDate, node.DateTime) < 0)
                {
                    LateDate = node.DateTime;
                }
            }
            string[] namesetarray = nameset.ToArray<string>();

            for (int i = 0; i < namesetarray.Length; i++)
            {
                var _curName = namesetarray[i];
                Dictionary<DateTime,string>  EeveayDataInfo = new Dictionary<DateTime, string>();
 
                for (DateTime start = earlyDate; DateTime.Compare(start, LateDate) < 0; start = start.AddDays(1))
                {
                    var _curDateTime = start;
                    List<InfoNode> t = _RawInfoList.GetRange(namestartpos[i], nameendpos[i] - namestartpos[i] + 1).FindAll(
                             delegate (InfoNode _tempnode)
                              {
                                  return _curDateTime.Date.Equals(_tempnode.DateTime.Date);
                              });

                    if (t.Count == 0)
                    {
                        EeveayDataInfo.Add(new DateTime(start.Year, start.Month, start.Day), " "); //无
                    }
                    else
                    {
                        TimeSpan timespan = t[t.Count - 1].DateTime - t[0].DateTime;
                        if (timespan.Seconds == 0)   //缺卡
                        {
                            if (t[0].DateTime.TimeOfDay.TotalHours <= 12)
                            {
                                EeveayDataInfo.Add(new DateTime(start.Year, start.Month, start.Day), "下午缺卡");
                            }else
                            {
                                EeveayDataInfo.Add(new DateTime(start.Year, start.Month, start.Day), "上午缺卡");
                            }
                        }
                        else if (timespan.TotalMinutes >= (8 * 60 + 90))  //有8小时
                        {
                            EeveayDataInfo.Add(new DateTime(start.Year, start.Month, start.Day), "8");
                        }
                        else  //不足8小时
                        {//
                            int alllenam = (int)(60 * 12 - t[0].DateTime.TimeOfDay.TotalMinutes);
                          //  alllenam = alllenam < 0 ? 0 : alllenam;
                          //  int allenpm= (int)( t[0].DateTime.TimeOfDay.TotalMinutes - 60 * 13.5);
                          //  allenpm = allenpm < 0 ? 0 : allenpm;
                          //  int alllen = alllenam + allenpm;
                          //  string args = "上午" + (int)(alllenam / 60) + "h" + (int)(alllenam % 60) + "m" + "下午" +
                          //      (int)(allenpm / 60) + "h" + (int)(allenpm % 60) + " 共 " + (int)(alllen / 60) + "h" + (int)(alllen % 60);
                          ////  EeveayDataInfo.Add(new DateTime(start.Year, start.Month, start.Day), "" + timespan.Hours + "h" + timespan.Minutes + "m");
                          //  EeveayDataInfo.Add(new DateTime(start.Year, start.Month, start.Day), args);

                           string teststring =  GetAmtime(t);
                            EeveayDataInfo.Add(new DateTime(start.Year, start.Month, start.Day), teststring);
                        }
                        //迟到
                        if (t[0].DateTime.TimeOfDay.TotalHours > 9.5)
                        {
                            int latetime = (int)(t[0].DateTime.TimeOfDay.TotalMinutes) - (570);
                            EeveayDataInfo[new DateTime(start.Year, start.Month, start.Day)] = EeveayDataInfo[new DateTime(start.Year, start.Month, start.Day)] + " 迟到" + latetime + "分";
                        }
                    }
                }
                LastInfo.Add(namesetarray[i], EeveayDataInfo);
            }
            Console.Out.WriteLine("");
        }

        private string GetAmtime(List<InfoNode> list)
        {
            List<DateTime> amlist = new List<DateTime>();
            List<DateTime> pmlist = new List<DateTime>();

            for (int i = 0; i < list.Count; i++)
            {
                if (list[i].DateTime.TimeOfDay.TotalMinutes <= 12 * 60)
                {
                    amlist.Add(list[i].DateTime);
                }
                if (list[i].DateTime.TimeOfDay.TotalMinutes > 13.5 * 60)
                {
                    pmlist.Add(list[i].DateTime);
                }
            }
            StringBuilder sb = new StringBuilder();
            sb.Append("上午");
            int alllenam = 0;
            if (amlist.Count == 0)
            {
                sb.Append("0h0m");
            }else if (amlist.Count == 1)
            {
                int startminutes = (int)(amlist[0].TimeOfDay.TotalMinutes) < (9 * 60) ? (9 * 60) :(int)( amlist[0].TimeOfDay.TotalMinutes); //
                alllenam = (int)(60 * 12 - startminutes);
                alllenam = alllenam < 0 ? 0 : alllenam;
                sb.Append("" + (int)(alllenam / 60) + "h" + (int)(alllenam % 60) + "m");
            }else
            {
                int startminutes = (int)(amlist[0].TimeOfDay.TotalMinutes) < (9 * 60) ? (9 * 60) : (int)(amlist[0].TimeOfDay.TotalMinutes);
                //9点以前到的，算9点
                //  TimeSpan timespan = amlist[amlist.Count - 1] - startminutes;
                //alllenam = (int)（timespan.TotalMinutes;

                alllenam = (int)(amlist[amlist.Count - 1].TimeOfDay.TotalMinutes - startminutes);
                sb.Append("" + (int)(alllenam / 60) + "h" + (int)(alllenam % 60) + "m");
            }

            sb.Append("下午");
            int allenpm = 0;
            if (pmlist.Count == 0)
            {
                sb.Append("0h0m");
            }
            else if (pmlist.Count == 1)
            {
                allenpm = (int)(pmlist[pmlist.Count -1].TimeOfDay.TotalMinutes - 60 * 13.5);
                allenpm = allenpm < 0 ? 0 : allenpm;

                sb.Append("" + (int)(allenpm / 60) + "h" + (int)(allenpm % 60) + "m");
            }
            else
            {
                TimeSpan timespan = pmlist[pmlist.Count - 1] - pmlist[0];
                allenpm = (int)timespan.TotalMinutes;
                sb.Append("" + (int)(allenpm / 60) + "h" + (int)(allenpm % 60) + "m");
            }

            int alllen =alllenam + allenpm;
            sb.Append(" 共 " + (int)(alllen / 60) + "h" + (int)(alllen % 60) + "m");

            return sb.ToString();
        }
    }
}
