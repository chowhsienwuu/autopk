﻿using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Spreadsheet;
//using SpreadsheetLight;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Spreadsheet;
//using SpreadsheetLight;
using Amba.SpreadsheetLight;
using System.IO;
using ExcelDataReader;
using NPOI.SS.UserModel;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using NPOI.HSSF.UserModel;
using NPOI.HSSF.Model;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            //  Open();
               Write();
           // Open1();
            //  open2();
        }
        /// <summary>
















        private void open2()
        {
            StringBuilder sbr = new StringBuilder();
            using (FileStream fs = File.OpenRead("D:\\1.xls"))   //打开myxls.xls文件
            {
                HSSFWorkbook wk = new HSSFWorkbook(fs);   //把xls文件中的数据写入wk中
                for (int i = 0; i < wk.NumberOfSheets; i++)  //NumberOfSheets是myxls.xls中总共的表数
                {
                    ISheet sheet = wk.GetSheetAt(i);   //读取当前表数据
                    for (int j = 0; j <= sheet.LastRowNum; j++)  //LastRowNum 是当前表的总行数
                    {
                        IRow row = sheet.GetRow(j);  //读取当前行数据
                        if (row != null)
                        {
                            sbr.Append("-------------------------------------\r\n"); //读取行与行之间的提示界限
                            for (int k = 0; k <= row.LastCellNum; k++)  //LastCellNum 是当前行的总列数
                            {
                                ICell cell = row.GetCell(k);  //当前表格
                                if (cell != null)
                                {
                                    sbr.Append(cell.ToString());   //获取表格中的数据并转换为字符串类型
                                }
                            }
                        }
                    }
                }
            }
            sbr.ToString();
            using (StreamWriter wr = new StreamWriter(new FileStream(@"d:/myText.txt", FileMode.Append)))  //把读取xls文件的数据写入myText.txt文件中
            {
                wr.Write(sbr.ToString());
                wr.Flush();
            }
        }

        private string rawfile = "D:\\1.xlsx";
        private void DoReadFile()
        {
            FileStream teststream = File.OpenRead(rawfile);
            using (var reader = ExcelReaderFactory.CreateReader(teststream))
            {
                int rowCount = reader.RowCount; //1872
                do
                {
                    while (reader.Read())
                    {
                        // reader.GetDouble(0);
                        Console.Out.WriteLine(" " + reader.RowCount + " "
                            + reader.GetString(2) + " " + reader.GetString(4)
                            + reader.GetValue(0));

                    }
                } while (reader.NextResult());
            }
            teststream.Close();
        }

        private void Open1()
        {
            FileStream teststream = File.OpenRead("D:\\1.xlsx");

        //    using (var stream = File.Open("‪D:\\1.xls", FileMode.Open, FileAccess.Read))
            {

                // Auto-detect format, supports:
                //  - Binary Excel files (2.0-2003 format; *.xls)
                //  - OpenXml Excel files (2007 format; *.xlsx)
                using (var reader = ExcelReaderFactory.CreateReader(teststream))
                {

                    // Choose one of either 1 or 2:

                    // 1. Use the reader methods
                    do
                    {
                        while (reader.Read())
                        {
                            if (reader.Depth != 0)
                            {
                                Console.Out.WriteLine(" " + reader.RowCount + " "
                                    + reader.GetString(2) + " " + reader.GetString(4)
                                    + reader.GetValue(0));
                            }
                        }
                    } while (reader.NextResult());

                    // 2. Use the AsDataSet extension method
                    var result = reader.AsDataSet();

                    // The result of each spreadsheet is in result.Tables
                }
            }
        }


        private void Open()
        {
            //using (SLDocument sl = new SLDocument())
            //{
                string file = "‪D:\\1.xls";
                //  FileStream fs = new FileStream(file, FileMode.Open);
                //  FileStream fs = new FileStream(file, FileMode.Open);
                Console.Out.WriteLine(" " + File.Exists("D:\\1.xls"));
                // File f = new File(file);
                SLDocument sheet = new SLDocument("D:\\3.xlsx");

                SLWorksheetStatistics stats = sheet.GetWorksheetStatistics();
                for (int j = 1; j < stats.EndRowIndex; j++)
                {
                    // Get the first column of the row (SLS is a 1-based index)
                    var value = sheet.GetCellValueAsString(j, 0);

                }
         //   }
            Console.Out.WriteLine(" " + File.Exists("D:\\1.xls"));
        }



        private void Write()
        {
            SLDocument sl = new SLDocument();
           
            // set a boolean at "A1"
            sl.SetCellValue("A1", true);

            // set at row 2, columns 1 through 20, a value that's equal to the column index
            for (int i = 1; i <= 20; ++i) sl.SetCellValue(2, i, i);

            // set the value of PI
            sl.SetCellValue("B3", 3.14159);

            // set the value of PI at row 4, column 2 (or "B4") in string form.
            // use this when you already have numeric data in string form and don't
            // want to parse it to a double or float variable type
            // and then set it as a value.
            // Note that "3,14159" is invalid. Excel (or Open XML) stores numerals in
            // invariant culture mode. Frankly, even "1,234,567.89" is invalid because
            // of the comma. If you can assign it in code, then it's fine, like so:
            // double fTemp = 1234567.89;
            sl.SetCellValueNumeric(4, 2, "3.14159");

            // normal string data
            sl.SetCellValue("C6", "This is at C6!");

            // typical XML-invalid characters are taken care of,
            // in particular the & and < and >
            sl.SetCellValue("I6", "Dinner & Dance costs < $10");

            // this sets a cell formula
            // Note that if you want to set a string that starts with the equal sign,
            // but is not a formula, prepend a single quote.
            // For example, "'==" will display 2 equal signs
            sl.SetCellValue(7, 3, "=SUM(A2:T2)");

            // if you need cell references and cell ranges *really* badly, consider the SLConvert class.
            sl.SetCellValue(SLConvert.ToCellReference(7, 4), string.Format("=SUM({0})", SLConvert.ToCellRange(2, 1, 2, 20)));

            // dates need the format code to be displayed as the typical date.
            // Otherwise it just looks like a floating point number.
            sl.SetCellValue("C8", new DateTime(3141, 5, 9));
            SLStyle style = sl.CreateStyle();
            style.FormatCode = "d-mmm-yyyy";
            sl.SetCellStyle("C8", style);

            sl.SetCellValue(8, 6, "I predict this to be a significant date. Why, I do not know...");

            sl.SetCellValue(9, 4, 456.123789);
            // we don't have to create a new SLStyle because
            // we only used the FormatCode property
            style.FormatCode = "0.000%";
            sl.SetCellStyle(9, 4, style);

            sl.SetCellValue(9, 6, "Perhaps a phenomenal growth in something?");

            sl.SaveAs("HelloWorld.xlsx");

        }




        HSSFWorkbook wb;
        HSSFSheet sh;
        private void button2_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < dataGridView1.RowCount - 1; i++)
            {
                if (sh.GetRow(i) == null)
                    sh.CreateRow(i);

                for (int j = 0; j < dataGridView1.ColumnCount; j++)
                {
                    if (sh.GetRow(i).GetCell(j) == null)
                        sh.GetRow(i).CreateCell(j);

                    if (dataGridView1[j, i].Value != null)
                    {
                        sh.GetRow(i).GetCell(j).SetCellValue(dataGridView1[j, i].Value.ToString());
                    }
                }
            }

            using (var fs = new FileStream("test.xls", FileMode.Open, FileAccess.Write))
            {
                wb.Write(fs);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // clear grid before filling
            dataGridView1.Rows.Clear();
            dataGridView1.Columns.Clear();

            // get sheet
            sh = (HSSFSheet)wb.GetSheet(comboBox1.SelectedItem.ToString());

            int i = 0;
            while (sh.GetRow(i) != null)
            {
                // add necessary columns
                if (dataGridView1.Columns.Count < sh.GetRow(i).Cells.Count)
                {
                    for (int j = 0; j < sh.GetRow(i).Cells.Count; j++)
                    {
                        dataGridView1.Columns.Add("", "");
                    }
                }

                // add row
                dataGridView1.Rows.Add();

                // write row value
                for (int j = 0; j < sh.GetRow(i).Cells.Count; j++)
                {
                    var cell = sh.GetRow(i).GetCell(j);

                    if (cell != null)
                    {
                        // TODO: you can add more cell types capability, e. g. formula
                        switch (cell.CellType)
                        {
                            case NPOI.SS.UserModel.CellType.Numeric:
                                dataGridView1[j, i].Value = sh.GetRow(i).GetCell(j).NumericCellValue;
                                break;
                            case NPOI.SS.UserModel.CellType.String:
                                dataGridView1[j, i].Value = sh.GetRow(i).GetCell(j).StringCellValue;
                                break;
                        }
                    }
                }

                i++;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // create xls if not exists
            //if (!File.Exists("test.xls"))
            //{
            //    wb = HSSFWorkbook.Create(InternalWorkbook.CreateWorkbook());

            //    // create sheet
            //    sh = (HSSFSheet)wb.CreateSheet("Sheet1");
            //    // 3 rows, 2 columns
            //    for (int i = 0; i < 3; i++)
            //    {
            //        var r = sh.CreateRow(i);
            //        for (int j = 0; j < 2; j++)
            //        {
            //            r.CreateCell(j);
            //        }
            //    }

            //    using (var fs = new FileStream("test.xls", FileMode.Create, FileAccess.Write))
            //    {
            //        wb.Write(fs);
            //    }
            //}

            // get sheets list from xls
            //using (var fs = new FileStream("D:\\1.xls", FileMode.Open, FileAccess.Read))
            //{
            //    FileStream mytest = File.OpenRead("D:\\3.xlsx");
            //    wb = new HSSFWorkbook(mytest);

            //    for (int i = 0; i < wb.Count; i++)
            //    {
            //        comboBox1.Items.Add(wb.GetSheetAt(i).SheetName);
            //    }
            //}
        }
    }
}
